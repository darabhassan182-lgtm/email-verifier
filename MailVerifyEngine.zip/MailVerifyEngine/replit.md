# Email Verification Tool

## Overview

A professional bulk email verification tool designed to validate email addresses comprehensively. It employs multiple techniques including format checking, DNS/MX record validation, SMTP verification, and detection of disposable or role-based addresses. The application provides a user-friendly, Material Design-inspired interface with real-time feedback during processing and supports exportable results.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture

**Framework**: React 18+ with TypeScript, using Vite for building.
**UI Component Library**: Shadcn/ui with Radix UI primitives, styled with Tailwind CSS for a "New York" style variant, supporting dark/light themes.
**State Management**: TanStack Query for server state; local React state for UI state. No global state management libraries are used.
**Routing**: Wouter for lightweight client-side routing.
**Design System**: Employs Inter font family, HSL-based neutral and accent color schemes, and consistent spacing with Tailwind utilities.

### Backend Architecture

**Runtime**: Node.js with Express.
**Language**: TypeScript with ES Modules.
**API Structure**: RESTful endpoints under `/api`, handling multipart form data via Multer for CSV uploads and returning JSON responses.
**Email Validation Logic**:
- Multi-stage pipeline: Regex format, disposable domain (4765+ GitHub-sourced), role-based email (32 prefixes), DNS MX lookup, catch-all domain detection (with caching), and SMTP verification with MX server fallback.
- Concurrent batch processing (10 emails in parallel) for speed.
- SMTP timeout increased to 45 seconds to accommodate slow mail servers, classifying timeouts as "risky" instead of "invalid."
- EHLO domain for SMTP verification dynamically set to production domain (REPLIT_DOMAINS) or "localhost" in development.
**Storage Strategy**: PostgreSQL database with Drizzle ORM.
- Tables: `verification_jobs` (stores job metadata) and `verification_results` (stores individual email results).
- Features chunked database writes (1000 rows per transaction), indexed queries, and unique constraints.
**Data Processing Flow**:
- **CSV Upload**: Client uploads CSV, server parses with PapaParse, extracts emails, and returns list for verification.
- **Email Verification**: Client initiates batch via `/api/verify-batch/start`, server creates job in DB and starts background processing. Real-time progress is streamed via Server-Sent Events (SSE) from `/api/verify-batch/progress/:jobId`. Results are persisted to the database after each batch and can be retrieved via `/api/verify-batch/results/:jobId`.
- **Results Export**: Client-side CSV generation from retrieved results.

### System Design Choices

- **Concurrent Batch Processing**: Achieved by processing 10 emails concurrently, saving results to the database after each batch, and providing real-time progress updates via SSE.
- **Robust SMTP Verification**: Includes MX server fallback, increased timeout (45s), and dynamic EHLO domain to ensure reliability across development and production environments.
- **Scalable Data Handling**: PostgreSQL integration with Drizzle ORM for persisting job and result data, supporting large batches (50k+ emails) with chunked writes and increased Express body parser limits (50MB).
- **Error Handling**: SMTP timeouts are classified as "risky," providing more granular feedback than a simple "invalid" status.

## External Dependencies

**Core Runtime Dependencies**:
- `@neondatabase/serverless`: PostgreSQL driver.
- `drizzle-orm`: SQL ORM for PostgreSQL.
- `express`: Web server framework.
- `multer`: Multipart form data parser.
- `papaparse`: CSV parsing library.
- `connect-pg-simple`: PostgreSQL session store (configured but not actively used for sessions).

**Frontend Libraries**:
- `react`, `react-dom`: UI framework.
- `@tanstack/react-query`: Server state management.
- `wouter`: Client-side routing.
- `react-hook-form`, `@hookform/resolvers`: Form handling.
- `zod`: Runtime schema validation.
- `@radix-ui/*`: Accessible UI primitives.
- `tailwindcss`: Utility-first CSS framework.
- `class-variance-authority`, `clsx`, `tailwind-merge`: Styling utilities.

**Development Dependencies**:
- `vite`: Build tool and dev server.
- `typescript`: Type system.
- `tsx`: TypeScript execution.
- `esbuild`: Production bundling.
- `@vitejs/plugin-react`: React support for Vite.

**External Services/APIs**:
- **GitHub**: For fetching disposable email domains (raw.githubusercontent.com).
- **DNS Resolution**: Node.js built-in `dns.promises` module.
- **Network Operations**: Node.js built-in `net` module for SMTP connections.