import { connect } from 'net';

export async function verifyEmailSMTP(
  email,
  mxHost,
  fromEmail = 'verify@example.com',
  heloHost = 'verification-service.com'
) {
  return new Promise((resolve) => {
    const timeout = 45000;
    const socket = connect({ host: mxHost, port: 25, timeout });
    
    let buffer = '';
    let step = 0;
    
    const cleanup = () => {
      socket.removeAllListeners();
      socket.destroy();
    };

    socket.on('data', (data) => {
      buffer += data.toString();
      
      const lines = buffer.split('\r\n');
      buffer = lines.pop() || '';
      
      for (const line of lines) {
        if (line.length < 3) continue;
        
        const code = parseInt(line.substring(0, 3));
        const isFinalLine = line.charAt(3) === ' ';
        
        if (!isFinalLine) continue;
        
        if (step === 0 && code === 220) {
          step = 1;
          socket.write(`EHLO ${heloHost}\r\n`);
        } else if (step === 1 && code === 250) {
          step = 2;
          socket.write(`MAIL FROM:<${fromEmail}>\r\n`);
        } else if (step === 2 && code === 250) {
          step = 3;
          socket.write(`RCPT TO:<${email}>\r\n`);
        } else if (step === 3) {
          cleanup();
          if (code === 250) {
            resolve({ valid: true, message: 'Accepted by server', code });
          } else {
            resolve({ valid: false, message: `Server rejected: ${line.trim()}`, code });
          }
          return;
        } else if (code >= 500) {
          cleanup();
          resolve({ valid: false, message: `Server error: ${line.trim()}`, code });
          return;
        }
      }
    });

    socket.on('error', (err) => {
      cleanup();
      resolve({ valid: false, message: `Connection error: ${err.message}` });
    });

    socket.on('timeout', () => {
      cleanup();
      resolve({ valid: false, message: 'Connection timeout', timedOut: true });
    });

    socket.on('close', () => {
      cleanup();
      if (step < 3) {
        resolve({ valid: false, message: 'Connection closed prematurely' });
      }
    });
  });
}

export async function verifyEmailSMTPWithFallback(email, mxRecords, fromEmail, heloHost) {
  let lastResult = null;
  
  for (const mx of mxRecords) {
    try {
      const result = await verifyEmailSMTP(email, mx.host, fromEmail, heloHost);
      lastResult = result;
      
      if (result.valid) {
        return result;
      }
      
      if (result.code && result.code >= 500 && result.code < 600) {
        return result;
      }
    } catch (error) {
      lastResult = { valid: false, message: `MX server ${mx.host} failed: ${error.message}` };
    }
  }
  
  return lastResult || { valid: false, message: 'All MX servers failed' };
}
