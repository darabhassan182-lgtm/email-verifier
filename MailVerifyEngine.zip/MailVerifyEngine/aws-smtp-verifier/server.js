import express from 'express';
import cors from 'cors';
import { verifyEmailSMTPWithFallback } from './smtp-core.js';

const app = express();
const PORT = process.env.PORT || 3000;
const API_KEY = process.env.API_KEY || 'your-secret-api-key-change-this';

app.use(cors());
app.use(express.json());

// API Key authentication middleware
function authenticate(req, res, next) {
  const authHeader = req.headers.authorization;
  
  if (!authHeader || !authHeader.startsWith('Bearer ')) {
    return res.status(401).json({ error: 'Missing or invalid authorization header' });
  }
  
  const token = authHeader.substring(7);
  
  if (token !== API_KEY) {
    return res.status(403).json({ error: 'Invalid API key' });
  }
  
  next();
}

// Health check endpoint
app.get('/health', (req, res) => {
  res.json({ status: 'ok', service: 'smtp-verifier' });
});

// SMTP verification endpoint
app.post('/verify-smtp', authenticate, async (req, res) => {
  const { email, mxRecords, fromEmail, heloHost } = req.body;
  
  if (!email || !mxRecords || !Array.isArray(mxRecords)) {
    return res.status(400).json({ 
      error: 'Missing required fields: email, mxRecords (array)' 
    });
  }
  
  try {
    const result = await verifyEmailSMTPWithFallback(
      email,
      mxRecords,
      fromEmail || 'verify@example.com',
      heloHost || 'verification-service.com'
    );
    
    res.json(result);
  } catch (error) {
    res.status(500).json({ 
      valid: false, 
      message: `Verification error: ${error.message}` 
    });
  }
});

app.listen(PORT, '0.0.0.0', () => {
  console.log(`SMTP Verifier running on port ${PORT}`);
  console.log(`API Key authentication: ${API_KEY ? 'enabled' : 'DISABLED - SET API_KEY!'}`);
});
