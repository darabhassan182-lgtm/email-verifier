# AWS CloudShell Deployment Guide

This guide walks you through deploying the SMTP verifier using AWS CloudShell (no local setup required!).

## Prerequisites

- AWS Account (free tier eligible)
- Credit card for AWS account verification

## Step 1: Create AWS Account

1. Go to https://aws.amazon.com
2. Click "Create an AWS Account"
3. Fill in your information:
   - Email address
   - Password
   - AWS account name
4. Add payment method (credit card)
5. Verify your identity (phone call)
6. Choose "Free" support plan
7. Wait for confirmation email

## Step 2: Access AWS Console

1. Go to https://console.aws.amazon.com
2. Sign in with your new account
3. Make sure you're in the **US East (N. Virginia)** region (top right corner)

## Step 3: Upload Files to CloudShell

1. In the AWS Console, click the **CloudShell icon** (terminal icon) at the bottom of the page
2. Wait for CloudShell to initialize (1-2 minutes first time)
3. Click **Actions** → **Upload file**
4. Upload these files from the `aws-smtp-verifier` folder:
   - `package.json`
   - `smtp-core.js`
   - `server.js`
   - `Dockerfile`
   - `deploy-cloudshell.sh`

## Step 4: Run Deployment Script

In CloudShell, run these commands:

```bash
# Make the script executable
chmod +x deploy-cloudshell.sh

# Generate a secure API key (save this!)
export API_KEY=$(openssl rand -hex 32)
echo "Your API Key: $API_KEY"
# COPY THIS KEY - YOU'LL NEED IT LATER!

# Run the deployment
./deploy-cloudshell.sh
```

The script will:
- Create a Docker container repository
- Build your SMTP verifier image
- Deploy it to AWS Fargate
- Set up networking and security
- Give you the public URL

**This takes about 5-10 minutes.**

## Step 5: Get Your Endpoint

At the end, the script will show:

```
Your SMTP Verifier is running at:
  http://12.34.56.78:3000

Add these secrets to your Replit project:
  AWS_SMTP_ENDPOINT: http://12.34.56.78:3000
  AWS_SMTP_API_KEY: abc123...
```

**Copy both values!**

## Step 6: Configure Replit

1. Go back to your Replit project
2. Click the **Secrets** (🔒) tab in the sidebar
3. Add two secrets:
   - Key: `AWS_SMTP_ENDPOINT`, Value: `http://YOUR_IP:3000`
   - Key: `AWS_SMTP_API_KEY`, Value: Your API key from Step 4

4. Restart your Replit app

## Step 7: Test It!

1. Go to your published Replit app
2. Upload a CSV with emails
3. Watch it verify quickly! 🎉

## Testing the AWS Service

Test the health endpoint:
```bash
curl http://YOUR_IP:3000/health
```

Should return:
```json
{"status":"ok","service":"smtp-verifier"}
```

Test SMTP verification:
```bash
curl -X POST http://YOUR_IP:3000/verify-smtp \
  -H "Authorization: Bearer YOUR_API_KEY" \
  -H "Content-Type: application/json" \
  -d '{
    "email": "test@gmail.com",
    "mxRecords": [{"priority": 10, "host": "gmail-smtp-in.l.google.com"}],
    "fromEmail": "verify@example.com",
    "heloHost": "verification-service.com"
  }'
```

## Troubleshooting

### CloudShell session expires
- Just re-upload the files and run the script again
- Your deployment will remain running

### Service won't start
- Check CloudWatch logs in AWS Console
- Go to: ECS → Clusters → smtp-verifier-cluster → Tasks → View logs

### Can't connect to endpoint
- Make sure you're using `http://` not `https://`
- Check security group allows port 3000
- Verify the public IP is correct

## Cost Estimate

- **First 3 months**: FREE (AWS Free Tier)
- **After free tier**: ~$15-25/month for 24/7 operation

## Stopping the Service (to save costs)

To stop the service when not in use:

```bash
aws ecs update-service \
  --cluster smtp-verifier-cluster \
  --service smtp-verifier-service \
  --desired-count 0 \
  --region us-east-1
```

To start it again:
```bash
aws ecs update-service \
  --cluster smtp-verifier-cluster \
  --service smtp-verifier-service \
  --desired-count 1 \
  --region us-east-1
```

## Need Help?

Common issues:
1. **"Access Denied"** - Make sure you're logged into the AWS account you created
2. **"VPC not found"** - Change region to US East (N. Virginia)
3. **Script fails** - Re-run it, it's safe to run multiple times
