#!/bin/bash
# Simplified AWS deployment script for CloudShell
# This script deploys the SMTP verifier to AWS ECS Fargate

set -e

echo "========================================="
echo "AWS SMTP Verifier Deployment Script"
echo "========================================="

# Configuration
REGION=${AWS_REGION:-us-east-1}
REPOSITORY_NAME="smtp-verifier"
CLUSTER_NAME="smtp-verifier-cluster"
SERVICE_NAME="smtp-verifier-service"
TASK_FAMILY="smtp-verifier-task"
API_KEY=${API_KEY:-$(openssl rand -hex 32)}

echo ""
echo "Configuration:"
echo "  Region: $REGION"
echo "  Repository: $REPOSITORY_NAME"
echo "  API Key: $API_KEY"
echo ""
read -p "Press Enter to continue or Ctrl+C to cancel..."

# Get AWS Account ID
ACCOUNT_ID=$(aws sts get-caller-identity --query Account --output text)
echo "AWS Account ID: $ACCOUNT_ID"

# Step 1: Create ECR Repository
echo ""
echo "Step 1: Creating ECR Repository..."
if aws ecr describe-repositories --repository-names $REPOSITORY_NAME --region $REGION 2>/dev/null; then
  echo "Repository already exists"
else
  aws ecr create-repository \
    --repository-name $REPOSITORY_NAME \
    --region $REGION
  echo "✓ Repository created"
fi

# Step 2: Build and Push Docker Image
echo ""
echo "Step 2: Building Docker image..."
ECR_URI="$ACCOUNT_ID.dkr.ecr.$REGION.amazonaws.com/$REPOSITORY_NAME"

# Login to ECR
aws ecr get-login-password --region $REGION | docker login --username AWS --password-stdin $ECR_URI

# Build image
docker build -t $REPOSITORY_NAME .

# Tag and push
docker tag $REPOSITORY_NAME:latest $ECR_URI:latest
docker push $ECR_URI:latest
echo "✓ Image pushed to ECR"

# Step 3: Create ECS Cluster
echo ""
echo "Step 3: Creating ECS Cluster..."
if aws ecs describe-clusters --clusters $CLUSTER_NAME --region $REGION --query 'clusters[0].status' --output text 2>/dev/null | grep -q ACTIVE; then
  echo "Cluster already exists"
else
  aws ecs create-cluster \
    --cluster-name $CLUSTER_NAME \
    --region $REGION
  echo "✓ Cluster created"
fi

# Step 4: Create IAM Role for ECS Task
echo ""
echo "Step 4: Creating IAM roles..."
TASK_ROLE_NAME="ecsTaskExecutionRole"

if aws iam get-role --role-name $TASK_ROLE_NAME 2>/dev/null; then
  echo "Task execution role already exists"
else
  # Create trust policy
  cat > /tmp/trust-policy.json <<EOF
{
  "Version": "2012-10-17",
  "Statement": [{
    "Effect": "Allow",
    "Principal": {
      "Service": "ecs-tasks.amazonaws.com"
    },
    "Action": "sts:AssumeRole"
  }]
}
EOF

  # Create role
  aws iam create-role \
    --role-name $TASK_ROLE_NAME \
    --assume-role-policy-document file:///tmp/trust-policy.json

  # Attach policy
  aws iam attach-role-policy \
    --role-name $TASK_ROLE_NAME \
    --policy-arn arn:aws:iam::aws:policy/service-role/AmazonECSTaskExecutionRolePolicy
  
  echo "✓ IAM role created"
fi

TASK_ROLE_ARN=$(aws iam get-role --role-name $TASK_ROLE_NAME --query 'Role.Arn' --output text)

# Step 5: Register Task Definition
echo ""
echo "Step 5: Registering task definition..."
cat > /tmp/task-definition.json <<EOF
{
  "family": "$TASK_FAMILY",
  "networkMode": "awsvpc",
  "requiresCompatibilities": ["FARGATE"],
  "cpu": "256",
  "memory": "512",
  "executionRoleArn": "$TASK_ROLE_ARN",
  "containerDefinitions": [{
    "name": "$REPOSITORY_NAME",
    "image": "$ECR_URI:latest",
    "portMappings": [{
      "containerPort": 3000,
      "protocol": "tcp"
    }],
    "environment": [
      {
        "name": "PORT",
        "value": "3000"
      },
      {
        "name": "API_KEY",
        "value": "$API_KEY"
      }
    ],
    "logConfiguration": {
      "logDriver": "awslogs",
      "options": {
        "awslogs-group": "/ecs/$TASK_FAMILY",
        "awslogs-region": "$REGION",
        "awslogs-stream-prefix": "ecs",
        "awslogs-create-group": "true"
      }
    }
  }]
}
EOF

aws ecs register-task-definition \
  --cli-input-json file:///tmp/task-definition.json \
  --region $REGION
echo "✓ Task definition registered"

# Step 6: Get Default VPC and Subnets
echo ""
echo "Step 6: Getting VPC configuration..."
VPC_ID=$(aws ec2 describe-vpcs --filters "Name=isDefault,Values=true" --query 'Vpcs[0].VpcId' --output text --region $REGION)
SUBNET_IDS=$(aws ec2 describe-subnets --filters "Name=vpc-id,Values=$VPC_ID" --query 'Subnets[*].SubnetId' --output text --region $REGION | tr '\t' ',')
echo "VPC: $VPC_ID"
echo "Subnets: $SUBNET_IDS"

# Step 7: Create Security Group
echo ""
echo "Step 7: Creating security group..."
SG_NAME="smtp-verifier-sg"
SG_ID=$(aws ec2 describe-security-groups --filters "Name=group-name,Values=$SG_NAME" "Name=vpc-id,Values=$VPC_ID" --query 'SecurityGroups[0].GroupId' --output text --region $REGION 2>/dev/null)

if [ "$SG_ID" = "None" ] || [ -z "$SG_ID" ]; then
  SG_ID=$(aws ec2 create-security-group \
    --group-name $SG_NAME \
    --description "Security group for SMTP verifier" \
    --vpc-id $VPC_ID \
    --region $REGION \
    --query 'GroupId' \
    --output text)
  
  # Allow inbound HTTP
  aws ec2 authorize-security-group-ingress \
    --group-id $SG_ID \
    --protocol tcp \
    --port 3000 \
    --cidr 0.0.0.0/0 \
    --region $REGION
  
  # Allow all outbound (for SMTP port 25)
  echo "✓ Security group created"
else
  echo "Security group already exists"
fi

echo "Security Group: $SG_ID"

# Step 8: Create ECS Service
echo ""
echo "Step 8: Creating ECS service..."
aws ecs create-service \
  --cluster $CLUSTER_NAME \
  --service-name $SERVICE_NAME \
  --task-definition $TASK_FAMILY \
  --desired-count 1 \
  --launch-type FARGATE \
  --network-configuration "awsvpcConfiguration={subnets=[$SUBNET_IDS],securityGroups=[$SG_ID],assignPublicIp=ENABLED}" \
  --region $REGION 2>/dev/null || echo "Service might already exist, updating..."

# Wait for service to stabilize
echo ""
echo "Waiting for service to start (this may take 2-3 minutes)..."
aws ecs wait services-stable \
  --cluster $CLUSTER_NAME \
  --services $SERVICE_NAME \
  --region $REGION

# Get the public IP
echo ""
echo "Getting public IP address..."
TASK_ARN=$(aws ecs list-tasks --cluster $CLUSTER_NAME --service-name $SERVICE_NAME --region $REGION --query 'taskArns[0]' --output text)
ENI_ID=$(aws ecs describe-tasks --cluster $CLUSTER_NAME --tasks $TASK_ARN --region $REGION --query 'tasks[0].attachments[0].details[?name==`networkInterfaceId`].value' --output text)
PUBLIC_IP=$(aws ec2 describe-network-interfaces --network-interface-ids $ENI_ID --region $REGION --query 'NetworkInterfaces[0].Association.PublicIp' --output text)

echo ""
echo "========================================="
echo "✓ DEPLOYMENT COMPLETE!"
echo "========================================="
echo ""
echo "Your SMTP Verifier is running at:"
echo "  http://$PUBLIC_IP:3000"
echo ""
echo "Add these secrets to your Replit project:"
echo "  AWS_SMTP_ENDPOINT: http://$PUBLIC_IP:3000"
echo "  AWS_SMTP_API_KEY: $API_KEY"
echo ""
echo "Test the health endpoint:"
echo "  curl http://$PUBLIC_IP:3000/health"
echo ""
echo "IMPORTANT: Save your API_KEY somewhere safe!"
echo "========================================="
