# Complete AWS SMTP Verifier Setup Guide
## (No Technical Experience Required)

This guide assumes you've never used AWS before. I'll walk you through EVERYTHING.

---

## 📋 PART 1: Create Your AWS Account (15 minutes)

### Step 1.1: Sign Up for AWS

1. **Open a web browser** and go to: https://aws.amazon.com

2. **Click the orange "Create an AWS Account" button** (top right corner)

3. **Fill in the form:**
   - **Email address:** Your email (you'll need access to it for verification)
   - **Password:** Create a strong password (save it!)
   - **AWS account name:** Any name you like (e.g., "My Email Verifier")
   - Click **"Continue"**

4. **Contact Information:**
   - Choose **"Personal"** (unless this is for a business)
   - Fill in your name, phone number, and address
   - Click **"Continue"**

5. **Payment Information:**
   - Enter your credit card details
   - ⚠️ **Don't worry:** We'll use the free tier, but AWS requires a card for identity verification
   - You won't be charged during the first 3 months
   - Click **"Verify and Continue"**

6. **Phone Verification:**
   - Enter your phone number
   - Choose **"Text message (SMS)"** or **"Voice call"**
   - Enter the 4-digit code you receive
   - Click **"Continue"**

7. **Choose Support Plan:**
   - Select **"Basic Support - Free"**
   - Click **"Complete sign up"**

8. **Wait for confirmation:**
   - You'll see "Congratulations!" message
   - Check your email for confirmation (may take 5-10 minutes)

---

## 📋 PART 2: Access AWS Console (2 minutes)

### Step 2.1: Log In

1. Go to: https://console.aws.amazon.com

2. Click **"Sign in to the Console"**

3. Choose **"Root user"**

4. Enter the **email** and **password** you used to create the account

5. You'll see the **AWS Management Console** - this is your dashboard

### Step 2.2: Check Your Region

**IMPORTANT:** Look at the **top-right corner** of the screen.

You'll see something like:
- "N. Virginia" or
- "Ohio" or
- "Oregon" etc.

**Click on it** and select **"US East (N. Virginia)"**

This is important because our script expects this region.

---

## 📋 PART 3: Open CloudShell (3 minutes)

### Step 3.1: Launch CloudShell

1. Look at the **top navigation bar** (black bar at the very top)

2. Find the **terminal/console icon** (looks like `>_`) near the search bar
   - If you don't see it, look for a button that says "CloudShell"

3. **Click the CloudShell icon**

4. A terminal window will open at the bottom of your screen

5. **First time only:** 
   - You'll see "Welcome to AWS CloudShell!"
   - Click **"Close"**
   - Wait 1-2 minutes while it sets up (shows "Preparing Environment...")

6. Once ready, you'll see a command prompt that looks like:
   ```
   [cloudshell-user@ip-xxx ~]$
   ```

**You're now in CloudShell!** This is a Linux terminal running in AWS.

---

## 📋 PART 4: Upload Files (5 minutes)

### Step 4.1: Download Files from Replit

**First, get the files from your Replit project:**

1. In your Replit project, go to the **Files panel** (left sidebar)

2. Find the **`aws-smtp-verifier`** folder

3. Download these 5 files to your computer:
   - Right-click each file → **Download**
   
   **Files to download:**
   - ✅ `package.json`
   - ✅ `smtp-core.js`
   - ✅ `server.js`
   - ✅ `Dockerfile`
   - ✅ `deploy-cloudshell.sh`

4. Save them all to a folder on your computer (e.g., Desktop/smtp-verifier)

### Step 4.2: Upload to CloudShell

**Back in CloudShell:**

1. Click the **"Actions"** button (top-right of CloudShell panel)

2. Select **"Upload file"**

3. A file picker opens - select **package.json**

4. Wait for "Upload complete" message (green checkmark)

5. **Repeat for all 5 files:**
   - Upload `smtp-core.js`
   - Upload `server.js`
   - Upload `Dockerfile`
   - Upload `deploy-cloudshell.sh`

6. **Verify upload:** Type this command and press Enter:
   ```bash
   ls -la
   ```
   
   You should see all 5 files listed.

---

## 📋 PART 5: Run the Deployment (10 minutes)

### Step 5.1: Prepare the Deployment Script

**Type each command below and press Enter after each one:**

1. **Make the script executable:**
   ```bash
   chmod +x deploy-cloudshell.sh
   ```
   (Nothing will appear - this is normal)

2. **Generate your API key:**
   ```bash
   export API_KEY=$(openssl rand -hex 32)
   ```

3. **See your API key:**
   ```bash
   echo "Your API Key: $API_KEY"
   ```
   
   **📝 IMPORTANT:** Copy this key! You'll see something like:
   ```
   Your API Key: a1b2c3d4e5f6...
   ```
   
   **Save this in a text file on your computer!**

### Step 5.2: Start Deployment

**Run the deployment script:**

```bash
./deploy-cloudshell.sh
```

**What will happen:**

1. You'll see:
   ```
   =========================================
   AWS SMTP Verifier Deployment Script
   =========================================
   
   Configuration:
     Region: us-east-1
     Repository: smtp-verifier
     API Key: a1b2c3d4...
   
   Press Enter to continue or Ctrl+C to cancel...
   ```

2. **Press Enter** to continue

3. The script will run for 5-10 minutes. You'll see progress messages:
   - ✓ Creating ECR Repository...
   - ✓ Building Docker image... (this takes 2-3 minutes)
   - ✓ Pushing image to ECR... (this takes 1-2 minutes)
   - ✓ Creating ECS Cluster...
   - ✓ Creating IAM roles...
   - ✓ Registering task definition...
   - ✓ Creating security group...
   - ✓ Creating ECS service...
   - Waiting for service to start... (this takes 2-3 minutes)

4. **Don't close the window!** Let it run until you see:
   ```
   =========================================
   ✓ DEPLOYMENT COMPLETE!
   =========================================
   
   Your SMTP Verifier is running at:
     http://12.34.56.78:3000
   
   Add these secrets to your Replit project:
     AWS_SMTP_ENDPOINT: http://12.34.56.78:3000
     AWS_SMTP_API_KEY: a1b2c3d4e5f6...
   ```

5. **📝 COPY BOTH VALUES:**
   - The **IP address** (e.g., `http://12.34.56.78:3000`)
   - The **API Key** (the long random string)

---

## 📋 PART 6: Test the AWS Service (2 minutes)

### Step 6.1: Test Health Endpoint

**In CloudShell, test that your service is running:**

```bash
# Replace 12.34.56.78 with YOUR IP from the previous step
curl http://12.34.56.78:3000/health
```

**Expected response:**
```json
{"status":"ok","service":"smtp-verifier"}
```

✅ **If you see this, your AWS service is working!**

❌ **If you see an error:**
- Wait 1-2 more minutes (service might still be starting)
- Try the curl command again

---

## 📋 PART 7: Connect Replit to AWS (3 minutes)

### Step 7.1: Add Secrets to Replit

1. **Go back to your Replit project** (in another browser tab)

2. **Click the lock icon** (🔒) in the left sidebar
   - This opens the "Secrets" panel

3. **Add first secret:**
   - Click **"New Secret"**
   - **Key:** `AWS_SMTP_ENDPOINT`
   - **Value:** `http://YOUR_IP_HERE:3000` (use the IP from Part 5)
   - Click **"Add Secret"**

4. **Add second secret:**
   - Click **"New Secret"** again
   - **Key:** `AWS_SMTP_API_KEY`
   - **Value:** Paste the API key from Part 5
   - Click **"Add Secret"**

### Step 7.2: Restart Your Replit App

1. Click the **"Stop"** button (if app is running)

2. Click **"Run"** button (or it will auto-start)

3. Wait for "serving on port 5000" message

---

## 📋 PART 8: Publish & Test Live Version (5 minutes)

### Step 8.1: Publish Your App

1. In Replit, click the **"Deploy"** button (top right)

2. Follow the prompts to publish your app

3. Get your **live URL** (looks like: `https://your-app.replit.app`)

### Step 8.2: Test Email Verification

1. **Open your live app** in a new tab

2. **Upload a CSV file** with some email addresses

3. **Click "Verify Emails"**

4. **Watch the magic happen!** 🎉
   - You should see real-time progress
   - Emails should verify quickly (not timing out)
   - Results should be accurate

---

## ✅ SUCCESS CHECKLIST

You're done when:
- ✅ AWS service shows "status: ok" when tested
- ✅ Replit has both secrets added (AWS_SMTP_ENDPOINT and AWS_SMTP_API_KEY)
- ✅ Published app verifies emails without timeouts
- ✅ You can see progress updates in real-time

---

## 🆘 TROUBLESHOOTING

### Problem: "Permission denied" error in CloudShell
**Solution:** You're not logged in as the right user
- Log out of AWS
- Log back in using the **Root user** (not IAM user)

### Problem: Can't find CloudShell icon
**Solution:** 
- Make sure you're in **US East (N. Virginia)** region
- Try searching "CloudShell" in the top search bar
- Click on it to open

### Problem: Script fails with "command not found"
**Solution:** Files didn't upload correctly
- Re-upload all 5 files
- Run `ls -la` to verify they're there
- Make sure file names match exactly (case-sensitive)

### Problem: "Connection timeout" when testing curl
**Solution:** Service is still starting
- Wait 2-3 more minutes
- Try curl command again
- Check if task is running: Go to ECS → Clusters → smtp-verifier-cluster

### Problem: Replit app still shows timeouts
**Solution:** 
- Check secrets are correct (no extra spaces)
- Make sure IP includes `http://` at the start
- Restart the Replit app
- Check CloudShell logs for errors

### Problem: AWS charges me money
**Solution:** 
- First 3 months are FREE (AWS Free Tier)
- After that, service costs ~$15-25/month
- To stop service and avoid charges:
  ```bash
  aws ecs update-service \
    --cluster smtp-verifier-cluster \
    --service smtp-verifier-service \
    --desired-count 0 \
    --region us-east-1
  ```

---

## 💰 COST BREAKDOWN

**First 3 months:** $0 (FREE - AWS Free Tier)

**After 3 months:**
- ECS Fargate: ~$15-20/month
- Data transfer: ~$2-5/month
- **Total: ~$17-25/month**

**To minimize costs:**
- Stop the service when not actively verifying emails
- Start it only when needed

---

## 📞 NEED HELP?

If you get stuck:
1. **Copy the exact error message** you're seeing
2. **Note which step** you're on
3. **Share with me** and I'll help troubleshoot

Common questions answered:
- "How do I stop the service?" → See Troubleshooting section above
- "Can I use a different region?" → Yes, but change `us-east-1` to your region in all commands
- "Is this secure?" → Yes, API key authentication protects your service
- "What if I lose my API key?" → You'll need to update the task definition with a new key

---

## 🎉 CONGRATULATIONS!

You've successfully deployed a professional email verification system on AWS! Your Replit app can now verify emails reliably on the published version.
