# AWS SMTP Verifier Microservice

This is a standalone SMTP verification service designed to run on AWS ECS Fargate.

## Deployment Steps

### 1. Install AWS CLI and Configure Credentials
```bash
aws configure
# Enter your AWS Access Key ID, Secret Access Key, and region
```

### 2. Create ECR Repository
```bash
aws ecr create-repository --repository-name smtp-verifier --region us-east-1
```

### 3. Build and Push Docker Image
```bash
# Get ECR login credentials
aws ecr get-login-password --region us-east-1 | docker login --username AWS --password-stdin YOUR_ACCOUNT_ID.dkr.ecr.us-east-1.amazonaws.com

# Build the image
docker build -t smtp-verifier .

# Tag the image
docker tag smtp-verifier:latest YOUR_ACCOUNT_ID.dkr.ecr.us-east-1.amazonaws.com/smtp-verifier:latest

# Push to ECR
docker push YOUR_ACCOUNT_ID.dkr.ecr.us-east-1.amazonaws.com/smtp-verifier:latest
```

### 4. Create ECS Cluster (via AWS Console)

1. Go to ECS → Clusters → Create Cluster
2. Choose "Networking only" (Fargate)
3. Name it "smtp-verifier-cluster"

### 5. Create Task Definition (via AWS Console)

1. Go to ECS → Task Definitions → Create new Task Definition
2. Choose Fargate
3. Configure:
   - Name: `smtp-verifier-task`
   - Task role: None (or create one if needed)
   - Network mode: awsvpc
   - Task memory: 512 MB
   - Task CPU: 256 (.25 vCPU)
4. Add Container:
   - Name: `smtp-verifier`
   - Image: `YOUR_ACCOUNT_ID.dkr.ecr.us-east-1.amazonaws.com/smtp-verifier:latest`
   - Port mappings: 3000 TCP
   - Environment variables:
     - `API_KEY`: Your secret key (use Secrets Manager for production)
     - `PORT`: 3000

### 6. Create Application Load Balancer

1. Go to EC2 → Load Balancers → Create Load Balancer
2. Choose Application Load Balancer
3. Configure:
   - Name: `smtp-verifier-alb`
   - Scheme: internet-facing
   - IP address type: IPv4
   - VPC: Default VPC
   - Subnets: Select at least 2 availability zones
4. Create Target Group:
   - Target type: IP
   - Protocol: HTTP
   - Port: 3000
   - Health check path: `/health`

### 7. Create ECS Service

1. Go to your cluster → Services → Create
2. Configure:
   - Launch type: Fargate
   - Task Definition: `smtp-verifier-task`
   - Service name: `smtp-verifier-service`
   - Number of tasks: 1 (scale up later if needed)
   - Load balancer type: Application Load Balancer
   - Select your ALB and target group
   - Auto-assign public IP: ENABLED

### 8. Get Your Service URL

After deployment, get the ALB DNS name:
- Go to EC2 → Load Balancers
- Copy the DNS name (e.g., `smtp-verifier-alb-123456789.us-east-1.elb.amazonaws.com`)

Your API endpoint will be:
```
https://smtp-verifier-alb-123456789.us-east-1.elb.amazonaws.com/verify-smtp
```

## Testing

```bash
curl -X POST https://YOUR_ALB_DNS/verify-smtp \
  -H "Authorization: Bearer your-secret-api-key" \
  -H "Content-Type: application/json" \
  -d '{
    "email": "test@gmail.com",
    "mxRecords": [{"priority": 10, "host": "gmail-smtp-in.l.google.com"}],
    "fromEmail": "verify@example.com",
    "heloHost": "verification-service.com"
  }'
```

## Cost Estimate

- **ECS Fargate**: ~$15-30/month for 1 task running 24/7
- **Application Load Balancer**: ~$18/month + data transfer
- **Total**: ~$35-50/month

## Environment Variables

- `PORT`: Server port (default: 3000)
- `API_KEY`: Authentication key for API requests (REQUIRED)

## Security Notes

1. **Use AWS Secrets Manager** for API_KEY in production
2. **Enable HTTPS** with ACM certificate on ALB
3. **Add rate limiting** to prevent abuse
4. **Restrict ALB security group** to only accept traffic from Replit IPs if possible
