import type { EmailResult } from '@shared/schema';

export async function uploadCSV(file: File): Promise<{ emails: string[]; total: number }> {
  const formData = new FormData();
  formData.append('file', file);

  const response = await fetch('/api/verify-emails', {
    method: 'POST',
    body: formData,
  });

  if (!response.ok) {
    const error = await response.json();
    throw new Error(error.error || 'Failed to upload CSV');
  }

  return response.json();
}

export async function verifySingleEmail(email: string): Promise<EmailResult> {
  const response = await fetch('/api/verify-single', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({ email }),
  });

  if (!response.ok) {
    const error = await response.json();
    throw new Error(error.error || 'Failed to verify email');
  }

  return response.json();
}

export async function startBatchVerification(
  emails: string[], 
  quickMode: boolean = false
): Promise<{ jobId: string; total: number }> {
  const response = await fetch('/api/verify-batch/start', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({ emails, quickMode }),
  });

  if (!response.ok) {
    const error = await response.json();
    throw new Error(error.error || 'Failed to start verification');
  }

  return response.json();
}

export interface ProgressUpdate {
  type: 'connected' | 'progress' | 'complete' | 'error';
  completed?: number;
  total?: number;
  status?: 'processing' | 'completed' | 'error';
  results?: EmailResult[];
  error?: string;
  message?: string;
}

export function subscribeToProgress(
  jobId: string,
  onProgress: (update: ProgressUpdate) => void,
  onComplete: (results: EmailResult[]) => void,
  onError: (error: string) => void
): () => void {
  const eventSource = new EventSource(`/api/verify-batch/progress/${jobId}`);

  eventSource.onmessage = (event) => {
    try {
      const update: ProgressUpdate = JSON.parse(event.data);
      
      if (update.type === 'progress') {
        onProgress(update);
      } else if (update.type === 'complete') {
        if (update.status === 'completed' && update.results) {
          onComplete(update.results);
        } else if (update.status === 'error') {
          onError(update.error || 'Unknown error');
        }
        eventSource.close();
      } else if (update.type === 'error') {
        onError(update.message || 'Unknown error');
        eventSource.close();
      }
    } catch (error) {
      console.error('Error parsing progress update:', error);
    }
  };

  eventSource.onerror = (error) => {
    console.error('EventSource error:', error);
    onError('Connection to server lost');
    eventSource.close();
  };

  // Return cleanup function
  return () => {
    eventSource.close();
  };
}

export function downloadCSV(results: EmailResult[], filename: string = 'email-verification-results.csv') {
  const headers = ['Email', 'Status', 'Reason', 'Details'];
  const rows = results.map(r => [r.email, r.status, r.reason, r.details]);
  
  const csvContent = [
    headers.join(','),
    ...rows.map(row => row.map(cell => `"${cell}"`).join(','))
  ].join('\n');

  const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
  const link = document.createElement('a');
  const url = URL.createObjectURL(blob);
  
  link.setAttribute('href', url);
  link.setAttribute('download', filename);
  link.style.visibility = 'hidden';
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
}
