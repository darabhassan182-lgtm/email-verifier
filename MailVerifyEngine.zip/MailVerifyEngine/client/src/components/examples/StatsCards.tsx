import StatsCards from '../StatsCards';

export default function StatsCardsExample() {
  return (
    <div className="p-8">
      <StatsCards total={150} valid={112} invalid={28} risky={10} />
    </div>
  );
}
