import FileUpload from '../FileUpload';

export default function FileUploadExample() {
  const handleFileSelect = (file: File) => {
    console.log('File selected:', file.name);
  };

  return (
    <div className="p-8">
      <FileUpload onFileSelect={handleFileSelect} />
    </div>
  );
}
