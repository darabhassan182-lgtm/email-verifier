import ProcessingStatus from '../ProcessingStatus';

export default function ProcessingStatusExample() {
  const handleCancel = () => {
    console.log('Verification cancelled');
  };

  return (
    <div className="p-8">
      <ProcessingStatus current={45} total={150} onCancel={handleCancel} />
    </div>
  );
}
