import ResultsTable, { EmailResult } from '../ResultsTable';

export default function ResultsTableExample() {
  const mockResults: EmailResult[] = [
    {
      email: 'john.doe@example.com',
      status: 'valid',
      reason: 'Accepted by server',
      details: 'MX records found, SMTP verified'
    },
    {
      email: 'test@mailinator.com',
      status: 'disposable',
      reason: 'Disposable domain detected',
      details: 'Known temporary email provider'
    },
    {
      email: 'info@company.com',
      status: 'role-based',
      reason: 'Role-based address detected',
      details: 'Potential spam trap'
    },
    {
      email: 'invalid@nonexistent.xyz',
      status: 'invalid',
      reason: 'No MX records',
      details: 'Domain invalid or no mail server'
    },
    {
      email: 'user@gmail.com',
      status: 'valid',
      reason: 'Accepted by server',
      details: 'MX records found, SMTP verified'
    }
  ];

  return (
    <div className="p-8">
      <ResultsTable results={mockResults} />
    </div>
  );
}
