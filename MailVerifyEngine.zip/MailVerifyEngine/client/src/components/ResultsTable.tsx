import { useState } from 'react';
import { CheckCircle, XCircle, AlertTriangle, ArrowUpDown, Search } from 'lucide-react';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';

export interface EmailResult {
  email: string;
  status: 'valid' | 'invalid' | 'disposable' | 'role-based' | 'catch-all' | 'risky';
  reason: string;
  details: string;
}

interface ResultsTableProps {
  results: EmailResult[];
}

export default function ResultsTable({ results }: ResultsTableProps) {
  const [searchTerm, setSearchTerm] = useState('');
  const [sortField, setSortField] = useState<'email' | 'status'>('email');
  const [sortDirection, setSortDirection] = useState<'asc' | 'desc'>('asc');

  const filteredResults = results.filter(result =>
    result.email.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const sortedResults = [...filteredResults].sort((a, b) => {
    const aValue = a[sortField];
    const bValue = b[sortField];
    const multiplier = sortDirection === 'asc' ? 1 : -1;
    return aValue.localeCompare(bValue) * multiplier;
  });

  const handleSort = (field: 'email' | 'status') => {
    if (sortField === field) {
      setSortDirection(sortDirection === 'asc' ? 'desc' : 'asc');
    } else {
      setSortField(field);
      setSortDirection('asc');
    }
  };

  const getStatusBadge = (status: EmailResult['status']) => {
    const configs = {
      valid: {
        variant: 'default' as const,
        icon: CheckCircle,
        label: 'Valid',
        className: 'bg-chart-2/10 text-chart-2 border-chart-2/20'
      },
      invalid: {
        variant: 'destructive' as const,
        icon: XCircle,
        label: 'Invalid',
        className: 'bg-destructive/10 text-destructive border-destructive/20'
      },
      disposable: {
        variant: 'secondary' as const,
        icon: AlertTriangle,
        label: 'Disposable',
        className: 'bg-chart-4/10 text-chart-4 border-chart-4/20'
      },
      'role-based': {
        variant: 'secondary' as const,
        icon: AlertTriangle,
        label: 'Role-based',
        className: 'bg-chart-4/10 text-chart-4 border-chart-4/20'
      },
      'catch-all': {
        variant: 'secondary' as const,
        icon: AlertTriangle,
        label: 'Catch-all',
        className: 'bg-chart-5/10 text-chart-5 border-chart-5/20'
      },
      'risky': {
        variant: 'secondary' as const,
        icon: AlertTriangle,
        label: 'Risky',
        className: 'bg-yellow-500/10 text-yellow-600 dark:text-yellow-500 border-yellow-500/20'
      }
    };

    const config = configs[status];
    const Icon = config.icon;

    return (
      <Badge variant={config.variant} className={`${config.className} gap-1`}>
        <Icon className="w-3 h-3" />
        {config.label}
      </Badge>
    );
  };

  return (
    <div className="w-full space-y-4">
      <div className="relative">
        <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-muted-foreground" />
        <Input
          placeholder="Search emails..."
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          className="pl-9"
          data-testid="input-search"
        />
      </div>

      <div className="border border-border rounded-md overflow-hidden">
        <div className="overflow-x-auto">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead
                  className="cursor-pointer hover-elevate active-elevate-2"
                  onClick={() => handleSort('email')}
                  data-testid="header-email"
                >
                  <div className="flex items-center gap-2">
                    Email Address
                    <ArrowUpDown className="w-4 h-4" />
                  </div>
                </TableHead>
                <TableHead
                  className="cursor-pointer hover-elevate active-elevate-2"
                  onClick={() => handleSort('status')}
                  data-testid="header-status"
                >
                  <div className="flex items-center gap-2">
                    Status
                    <ArrowUpDown className="w-4 h-4" />
                  </div>
                </TableHead>
                <TableHead>Reason</TableHead>
                <TableHead>Details</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {sortedResults.map((result, index) => (
                <TableRow key={index} data-testid={`row-result-${index}`}>
                  <TableCell className="font-medium font-mono text-sm" data-testid={`email-${index}`}>
                    {result.email}
                  </TableCell>
                  <TableCell data-testid={`status-${index}`}>
                    {getStatusBadge(result.status)}
                  </TableCell>
                  <TableCell className="text-muted-foreground" data-testid={`reason-${index}`}>
                    {result.reason}
                  </TableCell>
                  <TableCell className="text-sm text-muted-foreground" data-testid={`details-${index}`}>
                    {result.details}
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </div>
      </div>

      {sortedResults.length === 0 && (
        <div className="text-center py-8 text-muted-foreground">
          No results found
        </div>
      )}
    </div>
  );
}
