import { Loader2, Zap } from 'lucide-react';
import { Progress } from '@/components/ui/progress';
import { Button } from '@/components/ui/button';

interface ProcessingStatusProps {
  current: number;
  total: number;
  onCancel?: () => void;
}

export default function ProcessingStatus({ current, total, onCancel }: ProcessingStatusProps) {
  const percentage = Math.round((current / total) * 100);
  const estimatedTimeRemaining = Math.ceil((total - current) * 0.5);

  return (
    <div className="w-full max-w-2xl mx-auto">
      <div className="bg-gradient-to-br from-card via-card to-accent/20 border border-card-border rounded-xl p-10 shadow-lg">
        <div className="flex items-center justify-center mb-8">
          <div className="relative">
            <div className="absolute inset-0 bg-primary/30 rounded-full blur-xl animate-pulse" />
            <div className="relative w-20 h-20 rounded-full bg-gradient-to-br from-primary to-primary/70 flex items-center justify-center shadow-lg">
              <Loader2 className="w-10 h-10 text-primary-foreground animate-spin" />
            </div>
          </div>
        </div>
        
        <h3 className="text-2xl font-bold text-center mb-2 bg-gradient-to-r from-foreground to-foreground/70 bg-clip-text" data-testid="text-status">
          Verifying Emails
        </h3>
        
        <p className="text-sm text-muted-foreground text-center mb-8 flex items-center justify-center gap-2" data-testid="text-progress">
          <Zap className="w-4 h-4 text-primary" />
          Processing {current} of {total} emails
        </p>

        <div className="space-y-6">
          <div>
            <Progress value={percentage} className="h-3 mb-3" data-testid="progress-bar" />
            <div className="flex items-center justify-between text-sm">
              <span className="text-muted-foreground font-medium">Progress</span>
              <span className="font-bold text-lg bg-gradient-to-r from-primary to-primary/70 bg-clip-text" data-testid="text-percentage">
                {percentage}%
              </span>
            </div>
          </div>

          <div className="flex items-center justify-between text-sm bg-muted/50 rounded-lg p-4">
            <span className="text-muted-foreground font-medium">Estimated time remaining</span>
            <span className="font-semibold text-foreground" data-testid="text-time-remaining">
              ~{estimatedTimeRemaining}s
            </span>
          </div>
        </div>

        {onCancel && (
          <Button
            variant="outline"
            className="w-full mt-8 hover-elevate"
            onClick={onCancel}
            data-testid="button-cancel"
          >
            Cancel Verification
          </Button>
        )}
      </div>
    </div>
  );
}
