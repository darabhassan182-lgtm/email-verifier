import { Sparkles } from 'lucide-react';

export default function EmptyState() {
  return (
    <div className="flex flex-col items-center justify-center py-12 px-4">
      <div className="relative mb-8">
        <div className="absolute inset-0 bg-primary/20 rounded-3xl blur-3xl" />
        <div className="relative w-32 h-32 rounded-3xl bg-gradient-to-br from-primary via-primary to-primary/70 flex items-center justify-center shadow-2xl">
          <Sparkles className="w-16 h-16 text-primary-foreground" />
        </div>
      </div>
      <h2 className="text-3xl font-bold mb-3 bg-gradient-to-r from-foreground to-foreground/70 bg-clip-text" data-testid="text-empty-title">
        Welcome to Email Verification
      </h2>
      <p className="text-muted-foreground text-center max-w-lg text-lg mb-2">
        Upload a CSV file to verify email addresses using advanced validation techniques
      </p>
      <div className="flex flex-wrap gap-2 justify-center mt-4 text-sm text-muted-foreground">
        <span className="bg-muted/50 px-3 py-1.5 rounded-full">DNS Checks</span>
        <span className="bg-muted/50 px-3 py-1.5 rounded-full">SMTP Validation</span>
        <span className="bg-muted/50 px-3 py-1.5 rounded-full">Disposable Detection</span>
      </div>
    </div>
  );
}
