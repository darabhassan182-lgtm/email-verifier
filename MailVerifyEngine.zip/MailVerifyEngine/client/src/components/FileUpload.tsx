import { useCallback, useState } from 'react';
import { Upload, FileText, X, Sparkles } from 'lucide-react';
import { Button } from '@/components/ui/button';

interface FileUploadProps {
  onFileSelect: (file: File) => void;
}

export default function FileUpload({ onFileSelect }: FileUploadProps) {
  const [isDragging, setIsDragging] = useState(false);
  const [selectedFile, setSelectedFile] = useState<File | null>(null);

  const handleDragOver = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(true);
  }, []);

  const handleDragLeave = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
  }, []);

  const handleDrop = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    
    const files = e.dataTransfer.files;
    if (files.length > 0 && files[0].name.endsWith('.csv')) {
      setSelectedFile(files[0]);
    }
  }, []);

  const handleFileInput = useCallback((e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (files && files.length > 0) {
      setSelectedFile(files[0]);
    }
  }, []);

  const handleUpload = () => {
    if (selectedFile) {
      onFileSelect(selectedFile);
    }
  };

  const handleRemove = () => {
    setSelectedFile(null);
  };

  return (
    <div className="w-full max-w-3xl mx-auto">
      <div
        onDragOver={handleDragOver}
        onDragLeave={handleDragLeave}
        onDrop={handleDrop}
        className={`
          relative rounded-lg transition-all duration-200
          ${isDragging 
            ? 'border-2 border-primary bg-primary/5 scale-[1.02]' 
            : selectedFile 
              ? 'border border-border bg-gradient-to-br from-card to-accent/30'
              : 'border-2 border-dashed border-border/60 bg-gradient-to-br from-card via-card to-accent/20'
          }
          ${!selectedFile ? 'min-h-72' : 'min-h-fit'}
        `}
      >
        {!selectedFile ? (
          <label
            htmlFor="file-upload"
            className="flex flex-col items-center justify-center h-full py-16 px-6 cursor-pointer group"
            data-testid="dropzone-upload"
          >
            <div className="relative mb-6">
              <div className="absolute inset-0 bg-primary/20 rounded-full blur-2xl group-hover:blur-3xl transition-all duration-300" />
              <div className="relative w-24 h-24 rounded-2xl bg-gradient-to-br from-primary to-primary/70 flex items-center justify-center shadow-lg group-hover:shadow-xl group-hover:scale-110 transition-all duration-300">
                <Upload className="w-12 h-12 text-primary-foreground" />
              </div>
            </div>
            
            <h3 className="text-2xl font-semibold text-foreground mb-2 group-hover:text-primary transition-colors">
              Drop your CSV file here
            </h3>
            <p className="text-muted-foreground mb-6 text-center max-w-md">
              or click to browse your files
            </p>
            
            <div className="flex items-center gap-2 text-sm text-muted-foreground bg-muted/50 px-4 py-2 rounded-full">
              <Sparkles className="w-4 h-4" />
              <span>Supports CSV files with email addresses</span>
            </div>
            
            <input
              id="file-upload"
              type="file"
              accept=".csv"
              onChange={handleFileInput}
              className="hidden"
              data-testid="input-file"
            />
          </label>
        ) : (
          <div className="p-8">
            <div className="flex items-start justify-between bg-gradient-to-r from-primary/5 to-accent/30 border border-primary/20 rounded-xl p-6 mb-6 shadow-sm">
              <div className="flex items-start gap-4 flex-1">
                <div className="w-14 h-14 rounded-xl bg-gradient-to-br from-primary to-primary/70 flex items-center justify-center shadow-md flex-shrink-0">
                  <FileText className="w-7 h-7 text-primary-foreground" />
                </div>
                <div className="flex-1 min-w-0">
                  <p className="font-semibold text-foreground text-lg mb-1" data-testid="text-filename">
                    {selectedFile.name}
                  </p>
                  <p className="text-sm text-muted-foreground" data-testid="text-filesize">
                    {(selectedFile.size / 1024).toFixed(2)} KB
                  </p>
                </div>
              </div>
              <Button
                size="icon"
                variant="ghost"
                onClick={handleRemove}
                className="flex-shrink-0 hover-elevate"
                data-testid="button-remove-file"
              >
                <X className="w-5 h-5" />
              </Button>
            </div>
            
            <Button
              onClick={handleUpload}
              size="lg"
              className="w-full bg-gradient-to-r from-primary to-primary/90 hover:from-primary/90 hover:to-primary shadow-lg shadow-primary/25 text-base font-semibold h-12"
              data-testid="button-start-verification"
            >
              <Sparkles className="w-5 h-5 mr-2" />
              Start Email Verification
            </Button>
          </div>
        )}
      </div>
      
      {!selectedFile && (
        <p className="text-xs text-center text-muted-foreground mt-4 flex items-center justify-center gap-2">
          <span className="w-1.5 h-1.5 rounded-full bg-chart-2" />
          Upload a CSV file with one email address per line
        </p>
      )}
    </div>
  );
}
