import { CheckCircle, XCircle, AlertTriangle, Mail } from 'lucide-react';
import { Card } from '@/components/ui/card';

interface StatsCardsProps {
  total: number;
  valid: number;
  invalid: number;
  risky: number;
}

export default function StatsCards({ total, valid, invalid, risky }: StatsCardsProps) {
  const stats = [
    {
      label: 'Total Processed',
      value: total,
      icon: Mail,
      gradient: 'from-chart-1 to-chart-1/70',
      bgGradient: 'from-chart-1/10 to-chart-1/5',
      testId: 'stat-total'
    },
    {
      label: 'Valid Emails',
      value: valid,
      icon: CheckCircle,
      gradient: 'from-chart-2 to-chart-2/70',
      bgGradient: 'from-chart-2/10 to-chart-2/5',
      testId: 'stat-valid'
    },
    {
      label: 'Invalid Emails',
      value: invalid,
      icon: XCircle,
      gradient: 'from-destructive to-destructive/70',
      bgGradient: 'from-destructive/10 to-destructive/5',
      testId: 'stat-invalid'
    },
    {
      label: 'Risky Addresses',
      value: risky,
      icon: AlertTriangle,
      gradient: 'from-chart-4 to-chart-4/70',
      bgGradient: 'from-chart-4/10 to-chart-4/5',
      testId: 'stat-risky'
    }
  ];

  return (
    <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
      {stats.map((stat) => (
        <Card 
          key={stat.label} 
          className={`p-6 bg-gradient-to-br ${stat.bgGradient} border-border/50 hover-elevate transition-all duration-200 hover:shadow-lg`}
          data-testid={stat.testId}
        >
          <div className="flex items-center justify-between mb-4">
            <div className={`w-10 h-10 rounded-lg bg-gradient-to-br ${stat.gradient} flex items-center justify-center shadow-md`}>
              <stat.icon className="w-5 h-5 text-white" />
            </div>
          </div>
          <div className={`text-3xl font-bold mb-1 bg-gradient-to-r ${stat.gradient} bg-clip-text text-transparent`} data-testid={`${stat.testId}-value`}>
            {stat.value}
          </div>
          <div className="text-sm font-medium text-muted-foreground">
            {stat.label}
          </div>
        </Card>
      ))}
    </div>
  );
}
