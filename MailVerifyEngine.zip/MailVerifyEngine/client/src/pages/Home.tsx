import { useState, useEffect, useRef } from 'react';
import { Download, Upload, Sparkles, Loader2, Zap } from 'lucide-react';
import Header from '@/components/Header';
import FileUpload from '@/components/FileUpload';
import StatsCards from '@/components/StatsCards';
import ResultsTable, { EmailResult } from '@/components/ResultsTable';
import EmptyState from '@/components/EmptyState';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { Progress } from '@/components/ui/progress';
import { Checkbox } from '@/components/ui/checkbox';
import { useToast } from '@/hooks/use-toast';
import { uploadCSV, startBatchVerification, subscribeToProgress, downloadCSV } from '@/lib/api';

type AppState = 'empty' | 'processing' | 'results';

export default function Home() {
  const [appState, setAppState] = useState<AppState>('empty');
  const [progress, setProgress] = useState({ current: 0, total: 0 });
  const [results, setResults] = useState<EmailResult[]>([]);
  const [quickMode, setQuickMode] = useState(false);
  const unsubscribeRef = useRef<(() => void) | null>(null);
  const { toast } = useToast();

  // Cleanup on unmount
  useEffect(() => {
    return () => {
      if (unsubscribeRef.current) {
        unsubscribeRef.current();
      }
    };
  }, []);

  const handleFileSelect = async (file: File) => {
    try {
      setAppState('processing');

      // Upload and parse CSV
      const { emails, total } = await uploadCSV(file);
      setProgress({ current: 0, total });

      // Start batch verification
      const { jobId } = await startBatchVerification(emails, quickMode);

      // Subscribe to progress updates
      unsubscribeRef.current = subscribeToProgress(
        jobId,
        (update) => {
          // Progress update
          if (update.completed !== undefined && update.total !== undefined) {
            setProgress({ current: update.completed, total: update.total });
          }
        },
        (finalResults) => {
          // Completion
          setResults(finalResults);
          setAppState('results');
          
          toast({
            title: 'Verification Complete',
            description: `Successfully verified ${finalResults.length} email addresses`,
          });
        },
        (error) => {
          // Error
          console.error('Verification error:', error);
          toast({
            title: 'Error',
            description: error || 'Failed to verify emails',
            variant: 'destructive',
          });
          setAppState('empty');
        }
      );
    } catch (error) {
      console.error('Error processing file:', error);
      toast({
        title: 'Error',
        description: error instanceof Error ? error.message : 'Failed to process file',
        variant: 'destructive',
      });
      setAppState('empty');
    }
  };

  const handleNewUpload = () => {
    if (unsubscribeRef.current) {
      unsubscribeRef.current();
      unsubscribeRef.current = null;
    }
    setAppState('empty');
    setProgress({ current: 0, total: 0 });
    setResults([]);
  };

  const handleDownload = () => {
    try {
      downloadCSV(results);
      toast({
        title: 'Success',
        description: 'Results downloaded successfully',
      });
    } catch (error) {
      toast({
        title: 'Error',
        description: 'Failed to download results',
        variant: 'destructive',
      });
    }
  };

  const stats = {
    total: results.length,
    valid: results.filter(r => r.status === 'valid').length,
    invalid: results.filter(r => r.status === 'invalid').length,
    risky: results.filter(r => r.status === 'disposable' || r.status === 'role-based' || r.status === 'catch-all' || r.status === 'risky').length
  };

  const progressPercentage = progress.total > 0 ? (progress.current / progress.total) * 100 : 0;

  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-background to-accent/10">
      <Header />
      
      <main className="max-w-7xl mx-auto px-4 md:px-8 py-12">
        {appState === 'empty' && (
          <div className="space-y-12">
            <EmptyState />
            
            {/* Quick Mode Option */}
            <div className="max-w-2xl mx-auto">
              <Card className="p-6 bg-card/80 border-border/50">
                <div className="flex items-start gap-4">
                  <Checkbox
                    id="quick-mode"
                    checked={quickMode}
                    onCheckedChange={(checked) => setQuickMode(checked as boolean)}
                    data-testid="checkbox-quick-mode"
                    className="mt-1"
                  />
                  <div className="flex-1">
                    <label
                      htmlFor="quick-mode"
                      className="flex items-center gap-2 font-medium cursor-pointer"
                    >
                      <Zap className="w-4 h-4 text-yellow-500" />
                      Quick Mode (Ultra Fast)
                    </label>
                    <p className="text-sm text-muted-foreground mt-1">
                      Skip SMTP verification for maximum speed. Only checks format, DNS/MX records, and risk factors (disposable, role-based). 
                      Best for large batches where speed is critical.
                    </p>
                  </div>
                </div>
              </Card>
            </div>
            
            <FileUpload onFileSelect={handleFileSelect} />
          </div>
        )}

        {appState === 'processing' && (
          <div className="py-12">
            <Card className="max-w-2xl mx-auto p-12 text-center space-y-8 bg-gradient-to-br from-card to-accent/10 border-border/50 shadow-lg">
              <div className="w-20 h-20 mx-auto rounded-2xl bg-gradient-to-br from-primary to-primary/70 flex items-center justify-center shadow-lg">
                <Loader2 className="w-10 h-10 text-white animate-spin" data-testid="spinner-processing" />
              </div>
              
              <div className="space-y-3">
                <h2 className="text-3xl font-bold" data-testid="text-processing-title">
                  Verifying Emails
                </h2>
                <p className="text-lg text-muted-foreground" data-testid="text-processing-description">
                  Processing with concurrent validation
                </p>
                <div className="space-y-2">
                  <div className="flex items-center justify-between text-sm text-muted-foreground">
                    <span data-testid="text-progress-count">
                      {progress.current} of {progress.total} verified
                    </span>
                    <span data-testid="text-progress-percentage">
                      {Math.round(progressPercentage)}%
                    </span>
                  </div>
                  <Progress value={progressPercentage} className="h-3" data-testid="progress-bar" />
                </div>
                <p className="text-sm text-muted-foreground">
                  Processing up to 100 emails simultaneously {quickMode ? '(Quick Mode - Ultra Fast)' : 'with full SMTP verification'}
                </p>
              </div>
            </Card>
          </div>
        )}

        {appState === 'results' && (
          <div className="space-y-8">
            <div className="flex flex-wrap items-center justify-between gap-4 bg-gradient-to-r from-card to-accent/20 border border-border/50 rounded-xl p-6 shadow-md">
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-chart-2 to-chart-2/70 flex items-center justify-center shadow-md">
                  <Sparkles className="w-6 h-6 text-white" />
                </div>
                <div>
                  <h2 className="text-2xl font-bold mb-1">Verification Complete</h2>
                  <p className="text-muted-foreground">
                    Your email list has been processed successfully
                  </p>
                </div>
              </div>
              <div className="flex gap-3">
                <Button
                  variant="outline"
                  onClick={handleNewUpload}
                  data-testid="button-new-upload"
                  className="gap-2 hover-elevate"
                >
                  <Upload className="w-4 h-4" />
                  Upload New File
                </Button>
                <Button
                  onClick={handleDownload}
                  data-testid="button-download"
                  className="gap-2 bg-gradient-to-r from-primary to-primary/90 shadow-lg shadow-primary/25"
                >
                  <Download className="w-4 h-4" />
                  Download CSV
                </Button>
              </div>
            </div>

            <StatsCards
              total={stats.total}
              valid={stats.valid}
              invalid={stats.invalid}
              risky={stats.risky}
            />

            <div className="bg-card border border-card-border rounded-xl p-6 shadow-md">
              <ResultsTable results={results} />
            </div>
          </div>
        )}
      </main>
    </div>
  );
}
