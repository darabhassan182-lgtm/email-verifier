import type { Express, Request, Response } from "express";
import { createServer, type Server } from "http";
import multer from "multer";
import Papa from "papaparse";
import { validateEmail, getStatusFromValidation, getDetailsFromValidation } from "./email-validator";
import { emailResultSchema, type EmailResult, type InsertVerificationResult } from "@shared/schema";
import { storage } from "./storage";

const upload = multer({ storage: multer.memoryStorage() });

// Simple mutex implementation for serializing async operations
class Mutex {
  private queue: Array<() => void> = [];
  private locked = false;

  async acquire(): Promise<() => void> {
    return new Promise((resolve) => {
      if (!this.locked) {
        this.locked = true;
        resolve(() => this.release());
      } else {
        this.queue.push(() => {
          this.locked = true;
          resolve(() => this.release());
        });
      }
    });
  }

  private release() {
    const next = this.queue.shift();
    if (next) {
      next();
    } else {
      this.locked = false;
    }
  }
}

// Utility function for concurrent batch processing with controlled concurrency
// Accepts optional onChunkComplete callback that runs after each concurrent batch
async function processBatch<T, R>(
  items: T[],
  processor: (item: T, index: number) => Promise<R>,
  concurrency: number = 10,
  onChunkComplete?: (chunkResults: R[]) => Promise<void>
): Promise<R[]> {
  const results: R[] = new Array(items.length);
  
  // Process items in chunks
  for (let i = 0; i < items.length; i += concurrency) {
    const chunk = items.slice(i, i + concurrency);
    const chunkResults = await Promise.all(
      chunk.map((item, chunkIndex) => 
        processor(item, i + chunkIndex).then(result => ({ index: i + chunkIndex, result }))
      )
    );
    
    // Store results in correct positions and collect for callback
    const chunkValues: R[] = [];
    chunkResults.forEach(({ index, result }) => {
      results[index] = result;
      chunkValues.push(result);
    });
    
    // Call onChunkComplete after each batch
    if (onChunkComplete) {
      await onChunkComplete(chunkValues);
    }
  }
  
  return results;
}

export async function registerRoutes(app: Express): Promise<Server> {
  // POST endpoint to upload CSV and verify emails
  app.post("/api/verify-emails", upload.single('file'), async (req, res) => {
    try {
      if (!req.file) {
        return res.status(400).json({ error: "No file uploaded" });
      }

      // Parse CSV file
      const csvContent = req.file.buffer.toString('utf-8');
      const parseResult = Papa.parse<string[]>(csvContent, {
        skipEmptyLines: true,
      });

      // Extract emails from CSV (assuming first column contains emails)
      const emails = parseResult.data
        .map(row => (Array.isArray(row) ? row[0] : row))
        .filter(email => email && typeof email === 'string' && email.includes('@'))
        .map(email => email.trim());

      if (emails.length === 0) {
        return res.status(400).json({ error: "No valid emails found in CSV" });
      }

      // Return emails for processing
      res.json({ emails, total: emails.length });
    } catch (error) {
      console.error('Error processing CSV:', error);
      res.status(500).json({ error: "Failed to process CSV file" });
    }
  });

  // POST endpoint to verify a single email
  app.post("/api/verify-single", async (req, res) => {
    try {
      const { email } = req.body;

      if (!email || typeof email !== 'string') {
        return res.status(400).json({ error: "Invalid email" });
      }

      const { results, status } = await validateEmail(email);
      
      const result: EmailResult = {
        email,
        status: getStatusFromValidation(status, results),
        reason: status,
        details: getDetailsFromValidation(results),
      };

      res.json(result);
    } catch (error) {
      console.error('Error verifying email:', error);
      res.status(500).json({ error: "Failed to verify email" });
    }
  });

  // POST endpoint to start batch verification with job ID
  app.post("/api/verify-batch/start", async (req, res) => {
    try {
      const { emails, quickMode = false } = req.body;

      if (!Array.isArray(emails) || emails.length === 0) {
        return res.status(400).json({ error: "Invalid emails array" });
      }

      // Generate job ID
      const jobId = `job-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;

      // Create job in database
      await storage.createVerificationJob({
        jobId,
        status: 'processing',
        totalEmails: emails.length,
        completedEmails: 0,
      });

      console.log(`[${jobId}] Starting batch verification: ${emails.length} emails, quickMode: ${quickMode}`);

      // Start processing in background
      (async () => {
        try {
          // Process emails concurrently (100 at a time for speed) with progress tracking
          // Save results to database after EACH concurrent batch
          await processBatch(
            emails,
            async (email: string, index: number) => {
              try {
                console.log(`[${jobId}] Verifying email ${index + 1}/${emails.length}: ${email}`);
                
                const { results, status } = await validateEmail(email, quickMode);
                
                const result: EmailResult = {
                  email,
                  status: getStatusFromValidation(status, results),
                  reason: status,
                  details: getDetailsFromValidation(results),
                };

                console.log(`[${jobId}] Result for ${email}: ${result.status} - ${result.reason}`);

                // Return database result object
                return {
                  jobId,
                  email: result.email,
                  status: result.status,
                  reason: result.reason,
                  details: result.details,
                  reachable: results.reachable || false,
                };
              } catch (error) {
                console.error(`[${jobId}] Error verifying ${email}:`, error);
                
                // Return error result
                return {
                  jobId,
                  email,
                  status: 'invalid' as const,
                  reason: 'Verification failed',
                  details: error instanceof Error ? error.message : 'Unknown error',
                  reachable: false,
                };
              }
            },
            100, // Process 100 emails concurrently for speed
            // onChunkComplete: Save results after EACH batch of 100 emails
            async (chunkResults: InsertVerificationResult[]) => {
              const validResults = chunkResults.filter(r => r !== null);
              if (validResults.length > 0) {
                await storage.createVerificationResults(validResults);
                await storage.incrementVerificationJobProgress(jobId, validResults.length);
                console.log(`[${jobId}] Saved and updated progress: ${validResults.length} results`);
              }
            }
          );

          // Mark job as completed
          await storage.completeVerificationJob(jobId);
          console.log(`[${jobId}] Batch verification completed: ${emails.length} emails processed`);
        } catch (error) {
          console.error(`[${jobId}] Batch verification error:`, error);
          await storage.failVerificationJob(jobId, error instanceof Error ? error.message : 'Unknown error');
        }
      })();

      // Return job ID immediately
      res.json({ jobId, total: emails.length });
    } catch (error) {
      console.error('Error starting batch verification:', error);
      res.status(500).json({ error: "Failed to start verification" });
    }
  });

  // Server-Sent Events endpoint for progress updates
  app.get("/api/verify-batch/progress/:jobId", async (req: Request, res: Response) => {
    const { jobId } = req.params;

    // Set headers for SSE
    res.writeHead(200, {
      'Content-Type': 'text/event-stream',
      'Cache-Control': 'no-cache',
      'Connection': 'keep-alive'
    });

    // Send initial connection message
    res.write('data: {"type":"connected"}\n\n');

    // Send progress updates
    const intervalId = setInterval(async () => {
      const job = await storage.getVerificationJob(jobId);

      if (!job) {
        res.write(`data: {"type":"error","message":"Job not found"}\n\n`);
        clearInterval(intervalId);
        res.end();
        return;
      }

      // Send progress update
      res.write(`data: ${JSON.stringify({
        type: 'progress',
        completed: job.completedEmails,
        total: job.totalEmails,
        status: job.status
      })}\n\n`);

      // If job is complete or errored, send final message and close
      if (job.status === 'completed' || job.status === 'error') {
        // Get all results from database
        const results = await storage.getVerificationResults(jobId);
        
        // Convert to EmailResult format for backwards compatibility
        const emailResults: EmailResult[] = results.map(r => ({
          email: r.email,
          status: r.status as any,
          reason: r.reason,
          details: r.details,
        }));
        
        res.write(`data: ${JSON.stringify({
          type: 'complete',
          status: job.status,
          results: emailResults,
        })}\n\n`);
        
        clearInterval(intervalId);
        res.end();
      }
    }, 500); // Update every 500ms

    // Clean up on client disconnect
    req.on('close', () => {
      clearInterval(intervalId);
    });
  });

  // GET endpoint to retrieve verification results for a job
  app.get("/api/verify-batch/results/:jobId", async (req, res) => {
    try {
      const { jobId } = req.params;

      const job = await storage.getVerificationJob(jobId);
      if (!job) {
        return res.status(404).json({ error: "Job not found" });
      }

      const results = await storage.getVerificationResults(jobId);
      
      // Convert to EmailResult format
      const emailResults: EmailResult[] = results.map(r => ({
        email: r.email,
        status: r.status as any,
        reason: r.reason,
        details: r.details,
      }));

      res.json({
        jobId: job.jobId,
        status: job.status,
        totalEmails: job.totalEmails,
        completedEmails: job.completedEmails,
        results: emailResults,
        createdAt: job.createdAt,
        completedAt: job.completedAt,
      });
    } catch (error) {
      console.error('Error retrieving results:', error);
      res.status(500).json({ error: "Failed to retrieve results" });
    }
  });

  const httpServer = createServer(app);

  return httpServer;
}
