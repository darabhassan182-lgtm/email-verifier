import { 
  type VerificationJob, 
  type InsertVerificationJob,
  type VerificationResult, 
  type InsertVerificationResult,
  verificationJobs,
  verificationResults,
} from "@shared/schema";
import { db } from "./db";
import { eq, desc, sql } from "drizzle-orm";

export interface IStorage {
  // Verification Job methods
  createVerificationJob(job: InsertVerificationJob): Promise<VerificationJob>;
  getVerificationJob(jobId: string): Promise<VerificationJob | undefined>;
  updateVerificationJobProgress(jobId: string, completedEmails: number): Promise<void>;
  incrementVerificationJobProgress(jobId: string, incrementBy: number): Promise<void>;
  completeVerificationJob(jobId: string): Promise<void>;
  failVerificationJob(jobId: string, error: string): Promise<void>;
  cancelVerificationJob(jobId: string): Promise<void>;
  
  // Verification Result methods
  createVerificationResult(result: InsertVerificationResult): Promise<VerificationResult>;
  createVerificationResults(results: InsertVerificationResult[]): Promise<void>;
  getVerificationResults(jobId: string): Promise<VerificationResult[]>;
}

export class DbStorage implements IStorage {
  async createVerificationJob(job: InsertVerificationJob): Promise<VerificationJob> {
    const [createdJob] = await db.insert(verificationJobs).values(job).returning();
    return createdJob;
  }

  async getVerificationJob(jobId: string): Promise<VerificationJob | undefined> {
    const [job] = await db.select().from(verificationJobs).where(eq(verificationJobs.jobId, jobId));
    return job;
  }

  async updateVerificationJobProgress(jobId: string, completedEmails: number): Promise<void> {
    await db.update(verificationJobs)
      .set({ completedEmails })
      .where(eq(verificationJobs.jobId, jobId));
  }

  async incrementVerificationJobProgress(jobId: string, incrementBy: number): Promise<void> {
    // Use parameterized SQL to increment atomically
    await db.execute(
      sql`UPDATE verification_jobs SET completed_emails = completed_emails + ${incrementBy} WHERE job_id = ${jobId}`
    );
  }

  async completeVerificationJob(jobId: string): Promise<void> {
    await db.update(verificationJobs)
      .set({ 
        status: 'completed',
        completedAt: new Date(),
      })
      .where(eq(verificationJobs.jobId, jobId));
  }

  async failVerificationJob(jobId: string, error: string): Promise<void> {
    await db.update(verificationJobs)
      .set({ 
        status: 'error',
        completedAt: new Date(),
      })
      .where(eq(verificationJobs.jobId, jobId));
  }

  async cancelVerificationJob(jobId: string): Promise<void> {
    await db.update(verificationJobs)
      .set({ 
        status: 'cancelled',
        completedAt: new Date(),
      })
      .where(eq(verificationJobs.jobId, jobId));
  }

  async createVerificationResult(result: InsertVerificationResult): Promise<VerificationResult> {
    const [createdResult] = await db.insert(verificationResults).values(result).returning();
    return createdResult;
  }

  async createVerificationResults(results: InsertVerificationResult[]): Promise<void> {
    if (results.length === 0) return;
    
    const CHUNK_SIZE = 1000;
    
    // Process in chunks with transaction for each chunk
    for (let i = 0; i < results.length; i += CHUNK_SIZE) {
      const chunk = results.slice(i, i + CHUNK_SIZE);
      
      // Insert chunk in a transaction
      await db.transaction(async (tx: any) => {
        await tx.insert(verificationResults).values(chunk);
      });
    }
  }

  async getVerificationResults(jobId: string): Promise<VerificationResult[]> {
    return await db.select().from(verificationResults)
      .where(eq(verificationResults.jobId, jobId))
      .orderBy(verificationResults.createdAt);
  }
}

export const storage = new DbStorage();
