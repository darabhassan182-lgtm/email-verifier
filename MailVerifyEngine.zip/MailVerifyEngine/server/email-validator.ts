import { promises as dns } from 'dns';
import { connect, Socket } from 'net';

// Fallback disposable domains list
const FALLBACK_DISPOSABLE_DOMAINS = new Set([
  'mailinator.com', '10minutemail.com', 'tempmail.org', 'guerrillamail.com',
  'sharklasers.com', 'trashmail.com', 'yopmail.com', 'dispostable.com',
  'throwawaymail.com', 'fakeinbox.com', 'getnada.com', 'tempmail.de',
  'maildrop.cc', 'harakirimail.com', 'spam4.me', 'tempmail.net',
  'temp-mail.org', 'throwawayemail.com', 'guerrillamailblock.com',
  'grr.la', 'guerrillamail.biz', 'guerrillamail.net',
]);

// GitHub-sourced disposable domains (loaded at startup)
let DISPOSABLE_DOMAINS = new Set(FALLBACK_DISPOSABLE_DOMAINS);

// Expanded role-based email prefixes (from Python code)
const ROLE_BASED_USERNAMES = new Set([
  'admin', 'administrator', 'info', 'support', 'sales', 'contact',
  'webmaster', 'no-reply', 'noreply', 'abuse', 'postmaster', 'help',
  'billing', 'marketing', 'team', 'office', 'hello', 'root', 'hostmaster',
  'sysadmin', 'feedback', 'privacy', 'security', 'jobs', 'career', 'press',
  'media', 'inquiries', 'legal', 'compliance', 'hr', 'accounts'
]);

// Cache for catch-all detection (domain -> boolean)
const catchAllCache = new Map<string, boolean>();

interface ValidationResult {
  formatValid: boolean;
  disposable?: boolean;
  roleBased?: boolean;
  catchAll?: boolean;
  mxFound?: boolean;
  reachable?: boolean;
  smtpValid?: boolean;
  smtpMsg?: string;
}

// Fetch disposable domains from GitHub
export async function fetchDisposableDomains(): Promise<void> {
  const url = 'https://raw.githubusercontent.com/disposable-email-domains/disposable-email-domains/master/disposable_email_blocklist.conf';
  
  try {
    const response = await fetch(url);
    if (!response.ok) {
      throw new Error(`HTTP error! status: ${response.status}`);
    }
    
    const text = await response.text();
    const domains = new Set<string>();
    
    for (const line of text.split('\n')) {
      const trimmed = line.trim().toLowerCase();
      if (trimmed && !trimmed.startsWith('#')) {
        domains.add(trimmed);
      }
    }
    
    if (domains.size > 0) {
      DISPOSABLE_DOMAINS = domains;
      console.log(`Loaded ${domains.size} disposable email domains from GitHub`);
    } else {
      console.warn('No domains loaded from GitHub, using fallback list');
    }
  } catch (error) {
    console.error('Failed to fetch disposable domains from GitHub:', error);
    console.log(`Using fallback list with ${FALLBACK_DISPOSABLE_DOMAINS.size} domains`);
    DISPOSABLE_DOMAINS = new Set(FALLBACK_DISPOSABLE_DOMAINS);
  }
}

// Generate random email for catch-all detection
function generateRandomEmail(domain: string): string {
  const chars = 'abcdefghijklmnopqrstuvwxyz0123456789';
  let randomString = '';
  for (let i = 0; i < 30; i++) {
    randomString += chars.charAt(Math.floor(Math.random() * chars.length));
  }
  return `${randomString}@${domain}`;
}

export function isValidEmailFormat(email: string): boolean {
  const pattern = /^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9-.]+$/;
  return pattern.test(email);
}

// Helper function to delay execution
function delay(ms: number): Promise<void> {
  return new Promise(resolve => setTimeout(resolve, ms));
}

export async function getMXRecords(
  domain: string, 
  retries: number = 1
): Promise<Array<{ priority: number; host: string }>> {
  for (let attempt = 0; attempt < retries; attempt++) {
    try {
      const records = await dns.resolveMx(domain);
      return records
        .map(r => ({ priority: r.priority, host: r.exchange }))
        .sort((a, b) => a.priority - b.priority);
    } catch (error: any) {
      if (retries > 1) {
        console.log(`Retry ${attempt + 1} for MX records of ${domain}: ${error.message}`);
      }
      if (attempt < retries - 1) {
        await delay(2000); // 2 second delay between retries
      }
    }
  }
  return [];
}

// Check if mail server is reachable (used in accuracy mode)
export async function isMailServerReachable(
  mxHost: string, 
  retries: number = 1
): Promise<boolean> {
  for (let attempt = 0; attempt < retries; attempt++) {
    try {
      await new Promise<void>((resolve, reject) => {
        const socket = connect({ host: mxHost, port: 25, timeout: 30000 }); // 30s timeout
        
        socket.on('connect', () => {
          socket.destroy();
          resolve();
        });
        
        socket.on('error', (err) => {
          socket.destroy();
          reject(err);
        });
        
        socket.on('timeout', () => {
          socket.destroy();
          reject(new Error('Connection timeout'));
        });
      });
      return true;
    } catch (error: any) {
      if (retries > 1) {
        console.log(`Retry ${attempt + 1} for reachability of ${mxHost}: ${error.message}`);
      }
      if (attempt < retries - 1) {
        await delay(2000); // 2 second delay between retries
      }
    }
  }
  return false;
}

export async function verifyEmailSMTP(
  email: string,
  mxHost: string,
  fromEmail: string = 'verify@example.com',
  timeout: number = 10000 // Default 10s, can be overridden for accuracy mode
): Promise<{ valid: boolean; message: string; code?: number; timedOut?: boolean }> {
  return new Promise((resolve) => {
    const socket: Socket = connect({ host: mxHost, port: 25, timeout });
    
    let buffer = '';
    let step = 0;
    
    const cleanup = () => {
      socket.removeAllListeners();
      socket.destroy();
    };

    socket.on('data', (data) => {
      buffer += data.toString();
      
      // Process complete lines
      const lines = buffer.split('\r\n');
      buffer = lines.pop() || ''; // Keep incomplete line in buffer
      
      for (const line of lines) {
        if (line.length < 3) continue;
        
        const code = parseInt(line.substring(0, 3));
        const isFinalLine = line.charAt(3) === ' '; // Space means final line, hyphen means more to come
        
        // Only process final lines to avoid pipelining issues
        if (!isFinalLine) continue;
        
        if (step === 0 && code === 220) {
          // Server ready, send EHLO
          // Use Replit domain if available, otherwise localhost
          const heloHost = process.env.REPLIT_DOMAINS 
            ? process.env.REPLIT_DOMAINS.split(',')[0] 
            : 'localhost';
          step = 1;
          socket.write(`EHLO ${heloHost}\r\n`);
        } else if (step === 1 && code === 250) {
          // EHLO accepted, send MAIL FROM
          step = 2;
          socket.write(`MAIL FROM:<${fromEmail}>\r\n`);
        } else if (step === 2 && code === 250) {
          // MAIL FROM accepted, send RCPT TO
          step = 3;
          socket.write(`RCPT TO:<${email}>\r\n`);
        } else if (step === 3) {
          // Check RCPT TO response
          cleanup();
          if (code === 250) {
            resolve({ valid: true, message: 'Accepted by server', code });
          } else {
            resolve({ valid: false, message: `Server rejected: ${line.trim()}`, code });
          }
          return;
        } else if (code >= 500) {
          // Permanent error
          cleanup();
          resolve({ valid: false, message: `Server error: ${line.trim()}`, code });
          return;
        }
      }
    });

    socket.on('error', (err) => {
      cleanup();
      resolve({ valid: false, message: `Connection error: ${err.message}` });
    });

    socket.on('timeout', () => {
      cleanup();
      resolve({ valid: false, message: 'Connection timeout', timedOut: true });
    });

    socket.on('close', () => {
      if (step < 3) {
        cleanup();
        resolve({ valid: false, message: 'Connection closed prematurely' });
      }
    });
  });
}

// Try SMTP verification with multiple MX servers (fallback)
export async function verifyEmailSMTPWithFallback(
  email: string,
  mxRecords: Array<{ priority: number; host: string }>,
  fromEmail: string = 'verify@example.com'
): Promise<{ valid: boolean; message: string; code?: number; timedOut?: boolean }> {
  // Direct SMTP verification (works on Replit - port 25 is allowed)
  let lastResult: { valid: boolean; message: string; code?: number; timedOut?: boolean } | null = null;
  
  for (const mx of mxRecords) {
    try {
      const result = await verifyEmailSMTP(email, mx.host, fromEmail);
      
      // Return on definitive success (250)
      if (result.code === 250) {
        return result;
      }
      
      // Return on permanent failure (5xx)
      if (result.code && result.code >= 500) {
        return result;
      }
      
      // For 4xx (temporary errors), connection errors, or timeouts, 
      // save result and try next MX server
      lastResult = result;
      continue;
    } catch (error) {
      // Try next MX server on exceptions
      continue;
    }
  }
  
  // If we tried all MX servers without definitive result, return last error
  return lastResult || { valid: false, message: 'Could not connect to any MX server' };
}

// Detect catch-all domains
export async function isCatchAllDomain(
  domain: string,
  mxRecords: Array<{ priority: number; host: string }>
): Promise<boolean> {
  // Check cache first
  if (catchAllCache.has(domain)) {
    return catchAllCache.get(domain)!;
  }
  
  // Generate random email and test it
  const fakeEmail = generateRandomEmail(domain);
  const result = await verifyEmailSMTPWithFallback(fakeEmail, mxRecords);
  
  const isCatchAll = result.code === 250;
  
  // Cache result (keep cache size reasonable)
  if (catchAllCache.size > 1000) {
    const firstKey = catchAllCache.keys().next().value;
    if (firstKey) {
      catchAllCache.delete(firstKey);
    }
  }
  catchAllCache.set(domain, isCatchAll);
  
  return isCatchAll;
}

export function isDisposableDomain(domain: string): boolean {
  return DISPOSABLE_DOMAINS.has(domain.toLowerCase());
}

export function isRoleBased(email: string): boolean {
  const username = email.split('@')[0].toLowerCase();
  return Array.from(ROLE_BASED_USERNAMES).some(
    role => username.startsWith(role) || username === role
  );
}

export async function validateEmail(
  email: string, 
  quickMode: boolean = false
): Promise<{ results: ValidationResult; status: string }> {
  const results: ValidationResult = { formatValid: false };

  // 1. Format validation
  results.formatValid = isValidEmailFormat(email);
  if (!results.formatValid) {
    return { results, status: 'Invalid format' };
  }

  const [username, domain] = email.toLowerCase().split('@');

  // 2. Risk analysis - disposable domains
  results.disposable = isDisposableDomain(domain);
  if (results.disposable) {
    return { results, status: 'Disposable domain detected' };
  }

  // 3. Risk analysis - role-based
  results.roleBased = isRoleBased(email);
  if (results.roleBased) {
    return { results, status: 'Role-based address detected (potential spam trap)' };
  }

  // 4. Domain validation - MX records
  const mxRecords = await getMXRecords(domain);
  results.mxFound = mxRecords.length > 0;

  if (!results.mxFound) {
    return { results, status: 'No MX records (domain invalid or no mail server)' };
  }

  // Quick mode: Skip SMTP verification for speed (only format + DNS + risk checks)
  if (quickMode) {
    results.reachable = true; // Assume reachable if MX exists
    return { results, status: 'Valid (quick check - MX found)' };
  }

  // 5. Catch-all detection
  const isCatchAll = await isCatchAllDomain(domain, mxRecords);
  results.catchAll = isCatchAll;
  
  if (isCatchAll) {
    return { results, status: 'Catch-all domain detected (cannot reliably verify mailbox)' };
  }

  // 6. SMTP validation with MX fallback
  const smtpResult = await verifyEmailSMTPWithFallback(email, mxRecords);
  
  results.smtpValid = smtpResult.valid;
  results.smtpMsg = smtpResult.message;
  results.reachable = smtpResult.valid || (!smtpResult.timedOut && smtpResult.code !== undefined);

  // If SMTP timed out, return as risky instead of invalid
  if (smtpResult.timedOut) {
    return { results, status: 'SMTP timeout (inconclusive - slow mail server)' };
  }

  if (!results.smtpValid) {
    return { results, status: smtpResult.message };
  }

  return { results, status: 'Valid' };
}

export function getStatusFromValidation(status: string, results: ValidationResult): 'valid' | 'invalid' | 'disposable' | 'role-based' | 'catch-all' | 'risky' {
  if (results.disposable) return 'disposable';
  if (results.roleBased) return 'role-based';
  if (results.catchAll) return 'catch-all';
  if (status.includes('timeout')) return 'risky'; // SMTP timeouts are risky, not invalid
  if (status === 'Valid' || status.includes('quick check')) return 'valid'; // Valid or quick mode valid
  return 'invalid';
}

export function getDetailsFromValidation(results: ValidationResult): string {
  const details = [];
  if (results.mxFound) details.push('MX records found');
  if (results.reachable) details.push('Server reachable');
  if (results.smtpValid) details.push('SMTP verified');
  if (results.catchAll) details.push('Catch-all domain');
  return details.join(', ') || 'No additional details';
}
