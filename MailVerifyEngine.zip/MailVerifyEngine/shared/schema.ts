import { pgTable, serial, varchar, text, integer, timestamp, boolean, index, unique } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Drizzle ORM schema for verification jobs
export const verificationJobs = pgTable("verification_jobs", {
  id: serial("id").primaryKey(),
  jobId: varchar("job_id", { length: 255 }).notNull().unique(),
  status: varchar("status", { length: 50 }).notNull().default('processing'),
  totalEmails: integer("total_emails").notNull(),
  completedEmails: integer("completed_emails").notNull().default(0),
  createdAt: timestamp("created_at").notNull().defaultNow(),
  completedAt: timestamp("completed_at"),
});

// Drizzle ORM schema for individual verification results
export const verificationResults = pgTable("verification_results", {
  id: serial("id").primaryKey(),
  jobId: varchar("job_id", { length: 255 }).notNull(),
  email: varchar("email", { length: 255 }).notNull(),
  status: varchar("status", { length: 50 }).notNull(),
  reason: text("reason").notNull(),
  details: text("details").notNull(),
  reachable: boolean("reachable").notNull().default(false),
  createdAt: timestamp("created_at").notNull().defaultNow(),
}, (table) => ({
  // Index on jobId for faster lookups
  jobIdIdx: index("verification_results_job_idx").on(table.jobId),
  // Unique constraint to prevent duplicate results for same email in same job
  uniqueJobEmail: unique("verification_results_job_email_unique").on(table.jobId, table.email),
}));

// Insert schemas
export const insertVerificationJobSchema = createInsertSchema(verificationJobs).omit({ 
  id: true,
  createdAt: true,
});

export const insertVerificationResultSchema = createInsertSchema(verificationResults).omit({
  id: true,
  createdAt: true,
});

// Types
export type VerificationJob = typeof verificationJobs.$inferSelect;
export type InsertVerificationJob = z.infer<typeof insertVerificationJobSchema>;
export type VerificationResult = typeof verificationResults.$inferSelect;
export type InsertVerificationResult = z.infer<typeof insertVerificationResultSchema>;

// Zod schemas for API validation (legacy - keeping for backwards compatibility)
export const emailResultSchema = z.object({
  email: z.string().email(),
  status: z.enum(['valid', 'invalid', 'disposable', 'role-based', 'catch-all', 'risky']),
  reason: z.string(),
  details: z.string(),
});

export type EmailResult = z.infer<typeof emailResultSchema>;

export const verifyEmailsRequestSchema = z.object({
  emails: z.array(z.string().email()),
});

export type VerifyEmailsRequest = z.infer<typeof verifyEmailsRequestSchema>;
