# Email Verification Tool - Design Guidelines

## Design Approach

**System Selected**: Material Design / Clean Dashboard Approach
**Rationale**: Utility-focused productivity tool requiring clear information hierarchy, data visualization, and efficient workflows. Reference: Linear, Notion, Google Cloud Console for data processing interfaces.

**Core Principles**:
- Clarity over decoration: Every element serves a functional purpose
- Immediate feedback: Real-time status updates during processing
- Scannable results: Easy-to-parse validation data at a glance
- Professional restraint: Clean, trustworthy interface for business use

---

## Typography System

**Font Stack**: Inter or System UI (via Google Fonts CDN)

**Hierarchy**:
- H1 (Page Title): text-3xl md:text-4xl, font-semibold
- H2 (Section Headers): text-2xl, font-semibold
- H3 (Card Titles): text-lg, font-medium
- Body: text-base, font-normal
- Small/Meta: text-sm, font-normal
- Labels: text-sm, font-medium, uppercase tracking-wide

---

## Layout System

**Spacing Primitives**: Use Tailwind units of 2, 4, 6, 8, 12, 16, 24
- Component padding: p-6 or p-8
- Section gaps: space-y-8 or space-y-12
- Card spacing: p-6
- Form element gaps: space-y-4

**Container Strategy**:
- Max width: max-w-6xl mx-auto
- Page padding: px-4 md:px-8
- Vertical rhythm: py-12 md:py-16

**Grid Structure**:
- Single column primary flow (no forced multi-column for main content)
- Results table: Full-width responsive table
- Stats cards: grid-cols-2 md:grid-cols-4 for metrics display

---

## Component Library

### 1. Header/Navigation
- Fixed or sticky header with app title/logo
- Simple navigation with minimal links (Home, Documentation)
- Subtle bottom border for separation

### 2. Upload Zone (Primary Feature)
- Large, prominent drag-and-drop area (min-h-64)
- Dashed border indicating drop zone
- Upload icon (Heroicons: CloudArrowUp) centered
- Clear instructions: "Drag CSV file here or click to browse"
- File requirements below (text-sm): "Accepts .csv files with email addresses"
- Selected file preview showing filename and size

### 3. Processing Interface
- Progress bar with percentage (0-100%)
- Current status text: "Verifying 45 of 150 emails..."
- Animated progress indicator (linear progress bar)
- Estimated time remaining
- Cancel button option

### 4. Results Display

**Stats Summary Cards** (above results table):
- Grid of 4 metric cards showing:
  - Total Processed
  - Valid Emails
  - Invalid Emails
  - Disposable/Role-based Detected
- Each card: Large number (text-3xl font-bold), label below (text-sm)

**Results Table**:
- Full-width responsive table with horizontal scroll on mobile
- Columns: Email Address | Status | Reason | Details
- Row styling: Alternating subtle backgrounds for readability
- Status badges with icons (Heroicons: CheckCircle, XCircle, ExclamationTriangle)
- Badge styles: Rounded-full, px-3 py-1, text-sm font-medium
- Sortable columns (clickable headers with sort icons)
- Search/filter bar above table

### 5. Action Buttons
- Primary: "Upload New File" (prominent, px-6 py-3)
- Secondary: "Download Results CSV" with download icon
- Button group for batch actions (if needed)

### 6. Empty States
- Centered empty state when no file uploaded
- Large icon (Heroicons: DocumentText)
- Heading: "Upload your email list to get started"
- Subtext with quick instructions
- Primary CTA button

---

## Images

**No Hero Image**: This is a utility tool, not a marketing page. Skip hero imagery.

**Icon Usage**: Heroicons throughout (via CDN)
- File upload icons
- Status indicators (check, x, warning)
- Action icons (download, refresh)

---

## Animations

**Minimal, Functional Only**:
- Progress bar fill animation (smooth transition)
- File upload hover state (subtle scale or border highlight)
- Table row hover (background shift)
- Loading spinner during processing
- NO decorative animations

---

## Accessibility

- All form inputs with proper labels (not just placeholders)
- Status badges with aria-labels for screen readers
- Keyboard navigation for table sorting/filtering
- Focus indicators on all interactive elements
- Error messages clearly associated with inputs

---

## Page Structure

**Single Page Application Layout**:

1. **Header** (sticky)
2. **Main Container** (max-w-6xl mx-auto py-12 px-4)
   - **Upload Section** (prominent, centered when empty)
   - **Processing Section** (shows during validation, replaces upload)
   - **Stats Cards** (appears after processing)
   - **Results Table** (full-width, appears after processing)
   - **Actions Bar** (download + new upload buttons)

**Responsive Behavior**:
- Mobile: Stack all elements vertically, full-width table with horizontal scroll
- Desktop: Maintain single-column flow, table expands to full container width

---

This design prioritizes speed, clarity, and efficient data processing workflows while maintaining a professional, trustworthy appearance suitable for business users.